git add . --all
git commit -m '...'
git push origin master
