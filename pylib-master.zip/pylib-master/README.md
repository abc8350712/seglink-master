# pylib

A repository containing a lot of python methods encapsulated on many common used build-in modules(os, sys, etc.) or popular libs (numpy, tensorflow, cv2, etc. ).
