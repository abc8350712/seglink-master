#encoding = utf-8

def cmd(cmd):
    import  commands
    return commands.getoutput(cmd)

