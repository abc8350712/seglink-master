#encoding = utf-8
import numpy as np

assert_true = np.testing.assert_
assert_equal = np.testing.assert_equal
assert_array_equal = np.testing.assert_array_equal
assert_almost_equal = np.testing.assert_almost_equal
